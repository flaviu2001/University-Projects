#pragma once

template <typename T>
class List
{
public:
	virtual void add(const T& elem) = 0;
	virtual int getSize() const = 0;

	virtual ~List() {}
};
