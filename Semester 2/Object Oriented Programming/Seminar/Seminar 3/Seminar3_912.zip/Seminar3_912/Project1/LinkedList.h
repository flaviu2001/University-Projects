#pragma once
#include "List.h"

template <typename T>
class LinkedList : public List<T>
{
	class Node
	{
	private:
		T data;
		Node* next;

	public:
		Node(const T& data);
		T& getData();
		Node* getNext();
		void setNext(Node* val);
	};

private:
	Node* first;
	int size;

public:
	LinkedList(Node* first = nullptr, int size = 0);
	LinkedList(const LinkedList& l);
	// LinkedList& operator=(const LinkedList& l); // TODO
	~LinkedList();
	void add(const T& elem) override;
	int getSize() const override;
};

template<typename T>
inline LinkedList<T>::Node::Node(const T& data): data{data}
{
}

template<typename T>
inline T& LinkedList<T>::Node::getData()
{
	return this->data;
}

template<typename T>
inline LinkedList<T>::Node* LinkedList<T>::Node::getNext()
{
	return this->next;
}

template<typename T>
inline void LinkedList<T>::Node::setNext(Node* val)
{
	this->next = val;
}

template<typename T>
inline LinkedList<T>::LinkedList(Node* first, int size): first{first}, size{size}
{
}

template<typename T>
inline LinkedList<T>::LinkedList(const LinkedList& l)
{
	Node* p = l.first;
	while (p != nullptr)
	{
		this->add(p->getData());
		p = p->getNext();
	}
}

template<typename T>
inline LinkedList<T>::~LinkedList()
{
	Node* p = this->first;
	while (p != nullptr)
	{
		Node* aux = p;
		p = p->getNext();
		delete aux;
	}
}

template<typename T>
inline void LinkedList<T>::add(const T& elem)
{
	Node* f = new Node{ elem };
	this->size++;
	if (this->first == nullptr)
	{
		this->first = f;
		return;
	}

	Node* p = this->first;
	while (p->getNext() != nullptr)
		p = p->getNext();
	p->setNext(f);
}

template<typename T>
inline int LinkedList<T>::getSize() const
{
	return this->size;
}
