#include "DynamicVector.h"
#include <crtdbg.h>
#include <iostream>
#include <vector>
#include "LinkedList.h"

//class Person
//{
//protected:
//	std::string name;
//
//public:
//	Person(const std::string& n) : name{ n } {}
//	std::string getName() { return name; }
//	virtual int f()
//	{
//		return 0;
//	}
//	virtual ~Person() {}
//};
//
//class Student : public Person
//{
//private:
//	int grade;
//public:
//	Student(const std::string& n, int g) : Person{ n }, grade{ g } {}
//	int f() override
//	{
//		return 1;
//	}
//};

class Repository
{
private:
	List<int>* list;

public:
	Repository(List<int>* l) : list{ l } {}
	void add(int elem)
	{
		this->list->add(elem);
	}
};

int main()
{
	List<int>* l = new DynamicVector<int>{};
	l->add(4);
	l->add(5);

	Repository repo{l};

	delete l;


	/*Person* s = new Student{"Ana", 10};
	std::cout << s->f();
	delete s;*/
	
	/*{
		DynamicVector<int> v{ 5 };
		v.add(1);
		v.add(2);
		v.add(3);

		for (auto it = v.begin(); it != v.end(); it++)
			std::cout << *it << " ";

		for (auto& x : v)
			std::cout << x << " ";
	}*/

	//std::vector<int> v2{};
	//v2.push_back(10);
	//v2.push_back(11);
	//v2.push_back(12);
	//std::vector<int>::iterator iter = v2.begin() + 1;
	//v2.erase(iter); // iter becomed invalid

	_CrtDumpMemoryLeaks();

	return 0;
}
