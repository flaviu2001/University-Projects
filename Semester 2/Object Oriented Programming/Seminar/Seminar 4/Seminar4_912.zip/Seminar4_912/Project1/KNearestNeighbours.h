#pragma once
#include "Classifier.h"
#include "Distance.h"

class KNearestNeighbours : 	public Classifier
{
private:
	int k;
	std::vector<Instance> instances;
	Distance* distance;

public:
	KNearestNeighbours(int k, Distance* dist) : k{ k }, distance{ dist } {}

	void train(const std::vector<Instance>& training_instances) override;
	std::vector<int> predict(const std::vector<Instance>& test_instances) override;

private:
	std::vector<Instance> get_closest_k(const Instance& instance);
	int predict_for_one_instance(const Instance& instance);
};

