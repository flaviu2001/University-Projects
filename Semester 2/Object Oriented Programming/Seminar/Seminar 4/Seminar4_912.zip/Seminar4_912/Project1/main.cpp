#include "Utils.h"
#include <vector>
#include "Classifier.h"
#include "KNearestNeighbours.h"
#include "Distance.h"
#include "ClassifierAlways1.h"

using namespace std;

int main()
{
	vector<Instance> dataset = load_data("Diabetes.csv");
	vector<Instance> training_instances{}, test_instances{};
	split_data(dataset, 0.33, training_instances, test_instances);

	Classifier* classifier = nullptr;
	Distance* distance = nullptr;

	int option = -1;
	cout << "What type of classifier? 1 - KNN, 2 - Always1.";
	cin >> option;

	if (option == 1)
	{
		int optionDist = -1;
		cout << "What type of distance? 1 - Euclidean, 2 - Manhattan.";
		cin >> optionDist;

		if (optionDist == 1)
			distance = new EuclideanDistance{};
		else
			distance = new ManhattanDistance{};

		classifier = new KNearestNeighbours{ 3, distance };
	}
	else
		classifier = new ClassifierAlways1{};

	classifier->train(training_instances);
	vector<int> predicted = classifier->predict(test_instances);

	delete classifier;
	delete distance;

	return 0;
}