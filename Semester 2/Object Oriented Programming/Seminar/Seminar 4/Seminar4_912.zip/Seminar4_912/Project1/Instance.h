#pragma once
#include <vector>
#include <iostream>

class Instance
{
private:
	std::vector<double> input;
	int output;

public:
	Instance() { output = -1; }
	std::vector<double> get_input() const { return input; }
	int get_output() const { return output; }

private:
	void reset_instance();

public:
	friend std::istream& operator>>(std::istream& is, Instance& instance);
};

