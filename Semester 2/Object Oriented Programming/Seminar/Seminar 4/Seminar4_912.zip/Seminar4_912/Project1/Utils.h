#pragma once
#include <string>
#include <vector>
#include "Instance.h"

/*
	Tokenizes a string.
	Input:	str - the string to be tokenized.
	delimiter - char - the delimiter used for tokenization
	Output: a vector of strings, containing the tokens
*/
std::vector<std::string> tokenize(const std::string& str, char delimiter);

// load data
std::vector<Instance> load_data(std::string filename);

// split in training and test
void split_data(std::vector<Instance> dataset, double factor, std::vector<Instance>& train, std::vector<Instance>& test);