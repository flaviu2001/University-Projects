#include "Instance.h"
#include <string>
#include "Utils.h"

using namespace std;

void Instance::reset_instance()
{
	this->input.clear();
	this->output = -1;
}

std::istream& operator>>(std::istream& is, Instance& instance)
{
	instance.reset_instance();

	std::string line{};
	getline(is, line);

	vector<string> tokens = tokenize(line, ',');
	if (tokens.size() == 0)
		return is;
	int i = 0;
	for (i = 0; i < tokens.size() - 1; i++)
		instance.input.push_back(stod(tokens[i]));
	instance.output = stoi(tokens[i]);
	
	return is;
}
