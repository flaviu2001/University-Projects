#include "KNearestNeighbours.h"
#include <algorithm>
#include <map>

using namespace std;

void KNearestNeighbours::train(const std::vector<Instance>& training_instances)
{
	this->instances = training_instances;
}

std::vector<int> KNearestNeighbours::predict(const std::vector<Instance>& test_instances)
{
	std::vector<int> predictions{};
	for (const Instance& inst : test_instances)
		predictions.push_back(this->predict_for_one_instance(inst));

	return predictions;
}

std::vector<Instance> KNearestNeighbours::get_closest_k(const Instance& instance)
{
	vector<Instance> closest_k{};

	vector<pair<Instance, double>> instances_distances; // [(i1, 8), (i2, 4.3), (i3, 6), ....]

	for (const Instance& inst: this->instances)
	{
		double dist = this->distance->compute(inst.get_input(), instance.get_input());
		instances_distances.push_back(pair<Instance, double>{inst, dist});
	}

	sort(instances_distances.begin(), instances_distances.end(),
		[](const auto& e1, const auto& e2) { return e1.second < e2.second; }); // [(i2, 4.3), (i3, 6), (i1, 8), ....]

	int i = 0;
	while (i < this->k)
		closest_k.push_back(instances_distances[i++].first);

	return closest_k;
}

int KNearestNeighbours::predict_for_one_instance(const Instance& instance)
{
	vector<Instance> closest_k = this->get_closest_k(instance);
	
	map<int, int> classes_values{}; // {0: 2, 1: 1}
	for (Instance& inst : closest_k)
	{
		int instance_class = inst.get_output();
		map<int, int>::iterator it = classes_values.find(instance_class);
		if (it == classes_values.end())
			classes_values.insert(pair<int, int>{instance_class, 1});
		else
			it->second++;
	}

	int majority_class = max_element(classes_values.begin(), classes_values.end(),
		[](const auto& e1, const auto& e2) {return e1.second < e2.second; })->first;

	return majority_class;
}
