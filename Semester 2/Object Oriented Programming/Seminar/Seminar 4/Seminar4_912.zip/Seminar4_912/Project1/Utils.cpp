#include "Utils.h"
#include <sstream>
#include <string>
#include <vector>
#include <math.h>
#include <fstream>

using namespace std;

vector<string> tokenize(const string& str, char delimiter)
{
	vector <string> result;
	stringstream ss(str);
	string token;
	while (getline(ss, token, delimiter))
		result.push_back(token);

	return result;
}

std::vector<Instance> load_data(std::string filename)
{
	ifstream file{ filename };
	std::vector<Instance> dataset{};

	Instance instance{};
	while (file >> instance)
		dataset.push_back(instance);
	
	file.close();
	
	return dataset;
}

void split_data(std::vector<Instance> dataset, double factor, std::vector<Instance>& train, std::vector<Instance>& test)
{
	size_t number_for_testing = static_cast<size_t>(factor * dataset.size());
	size_t number_for_training = dataset.size() - number_for_testing;
	size_t i = 0;
	for (i = 0; i < number_for_training; i++)
		train.push_back(dataset[i]);
	while (i < dataset.size())
		test.push_back(dataset[i++]);

}
