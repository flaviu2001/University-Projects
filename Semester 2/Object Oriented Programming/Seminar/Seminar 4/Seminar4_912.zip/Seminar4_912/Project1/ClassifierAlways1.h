#pragma once
#include "Classifier.h"

class ClassifierAlways1 : public Classifier
{
	void train(const std::vector<Instance>& training_instances) override;
	std::vector<int> predict(const std::vector<Instance>& test_instances) override;
};

