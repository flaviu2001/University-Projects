#include "Distance.h"
#include <algorithm>
#include <numeric>

using namespace std;

double EuclideanDistance::compute(const std::vector<double>& v1, const std::vector<double>& v2)
{
	// v1 = [2, 4, 7], v2 = [1, 4, 9]
	// squaredDiff = [1, 0, 4]

	vector<double> squaredDiff{};
	transform(v1.begin(), v1.end(), v2.begin(), back_inserter(squaredDiff),
		[](double e1, double e2) {return pow((e1 - e2), 2); });

	return sqrt(accumulate(squaredDiff.begin(), squaredDiff.end(), 0.0));
}

double ManhattanDistance::compute(const std::vector<double>& v1, const std::vector<double>& v2)
{
	vector<double> absDiff{};
	transform(v1.begin(), v1.end(), v2.begin(), back_inserter(absDiff),
		[](double e1, double e2) {return abs(e1 - e2); });

	return accumulate(absDiff.begin(), absDiff.end(), 0.0);
}
