#include "ClassifierAlways1.h"

void ClassifierAlways1::train(const std::vector<Instance>& training_instances)
{
}

std::vector<int> ClassifierAlways1::predict(const std::vector<Instance>& test_instances)
{
	return std::vector<int>(test_instances.size(), 1);
}
