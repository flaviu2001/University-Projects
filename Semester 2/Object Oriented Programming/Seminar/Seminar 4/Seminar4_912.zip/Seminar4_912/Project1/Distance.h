#pragma once
#include <vector>

class Distance
{
public:
	virtual double compute(const std::vector<double>& v1, const std::vector<double>& v2) = 0;

	virtual ~Distance() {}
};

class EuclideanDistance : public Distance
{
public:
	double compute(const std::vector<double>& v1, const std::vector<double>& v2) override;
};

class ManhattanDistance : public Distance
{
public:
	double compute(const std::vector<double>& v1, const std::vector<double>& v2) override;
};

