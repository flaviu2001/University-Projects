#include "lecture12_demo_observer.h"

Lecture12_demo_Observer::Lecture12_demo_Observer(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lecture12_demo_Observer::~Lecture12_demo_Observer()
{

}
