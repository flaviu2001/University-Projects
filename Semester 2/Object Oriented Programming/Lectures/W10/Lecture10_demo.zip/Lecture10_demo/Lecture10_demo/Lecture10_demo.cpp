#include "Lecture10_demo.h"

Lecture10_demo::Lecture10_demo(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
