#include "IntrospectionExample.h"

IntrospectionExample::IntrospectionExample(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
