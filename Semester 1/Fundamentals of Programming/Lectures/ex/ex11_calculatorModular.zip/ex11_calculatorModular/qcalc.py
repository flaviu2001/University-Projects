"""
 Start the calculator application
"""
from ui.console import run

# invoke the run method from the module ui.console
run()
